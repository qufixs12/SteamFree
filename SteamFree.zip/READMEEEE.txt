--------------------------------------------------------------------------
⚠️ IMPORTANT ⚠️

KEEP THE _INTERNAL FOLDER AND DISCORDBOT.EXE
IN THE SAME FILE PATH.

DO NOT MOVE OR SEPARATE THEM,
OR THE BOT WILL NOT COME ONLINE.

--------------------------------------------------------------------------
    THINGS NEEDED!!!

https://www.steamtools.net/     Needed to download any steam game.

https://steamdb.info/       Helps find steam app id's.

https://discord.gg/KyxMzwFxT8   Game fix's can be found here.

https://online-fix.me/     Online fix's can be found here.

--------------------------------------------------------------------------

USAGE
-----
1. Run the EXE
   This brings the bot online.
   Do NOT close it while generating.

2. Open Discord
   Navigate to the Game-Gen channel.

3. Use the generation command:
   !gen <app_id>

   Example:
   !gen 271590

4. Wait for the bot to respond and provide the download/output.

5. Open SteamTools.

6. Drag and drop all files into steam tools icon.

7. Right click steam tools click reload on the floting SteamTools icon.

8. Download the game.
--------------------------------------------------------------------------

🔒 Antivirus Warning (False Positive)
The EXE is safe. Antivirus flags it because it’s packed with Python libraries using PyInstaller, which often triggers generic “Trojan/Malware” detections. These are normal Python and Windows components—not real malware.
Fix: Just add the EXE to your antivirus exclusions or scan it on VirusTotal for extra confirmation.